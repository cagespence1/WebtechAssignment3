var express = require('express');
var JSONWebToken = require('jsonwebtoken');
var router = express.Router();
var privateKey = 'SuperSecretKey';

router.use(function (req, res, next){

    // Get the token from the request header
    var token = req.headers.authorization;

    // Check all requests except post user, get movies
    console.log(req.method);
    console.log(req.path);
    if (req.method == 'POST' &&
        // req.path === '/users' ||
        req.path == '/authorize'){
        next();
    }



    // Verify the token
    JSONWebToken.verify(token, privateKey, function(err, decoded){

        if (err){
            next();
            // error = new Error('Token invalid');
            // error.status = 400;
            // throw error;
        } else {
            // todo see if the user included in the token is valid
            console.log('token good');
            // req.token = decoded;
            next();
        }
    })

});

module.exports = router;