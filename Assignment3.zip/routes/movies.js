var express = require('express');
var Movie = require('../models/movie');
var router = express.Router();

/**
 * Find all movies
 */
router.get('/', function (req, res, next) {

    Movie.findAll()

        .then(function (movies) {
            res.json(movies);
        })

        .catch(function (error){
            next(error);
        })
});

/**
 * Find movie by ttnumber
 */
router.get('/:tt_number', function (req, res, next) {

    Movie.findByTtNumber(req.params.tt_number)

        .then(function (movie) {

            if (!movie){
                error = new Error('No movie found');
                error.status = 404;
                throw error;
            }

            res.json(movie);
        })

        .catch(function (error){
            next(error);
        })
});

router.post('/', function(req, res, next) {
    Movie.createMovie(req);
});

module.exports = router;