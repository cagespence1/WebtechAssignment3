var Express = require('express');
var router = Express.Router();
var JSONWebToken = require('jsonwebtoken');
var User = require('../models/user');

var privateKey = 'SuperSecretKey';

router.post('/', function (req, res, next) {

    var username = req.body.username;
    var password = req.body.password;

    if (!username) {
        res.status(400).json({message: 'Missing username'})
    }

    if (!password) {
        res.status(400).json({message: 'Missing password'})
    }

    // Find user
    var user = User.findByUsernameWithPassword(username)
        .then(function (user) {

            console.log(user);

            if (!user) {

                error = new Error('No user found');
                error.status = 404;
                throw error;

            }

            if (user.password !== password) {

                console.log(password + ' - ' + user.password);
                error = new Error('Wrong password');
                error.status = 401;
                throw error;

            } else {

                var token = JSONWebToken.sign({username: username}, privateKey,{
                    expiresIn: "10 minutes"
                });
                res.json({token: token});

            }

        })

        .catch(function (err) {
            next(err);
        })

});

module.exports = router;